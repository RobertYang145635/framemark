# E4 阶段一字体来源（自有副本，不改 `engine/assets`）

手写卡用到的 @fontsource / 系统面在 22 件字体包里没有或不可读，E4 把它们落到本目录。
**这些都是替身副本，不是 `engine/assets` 的原始文件**；依据见 `_research/native/E4.md` §3.5/§6.3。

## 1. WOFF1 → sfnt（轮廓不变，只换容器）

`framemark/engine/e4-hand/tools/fonts-prepare.cjs`：

| 文件 | 源（`framemark/node_modules/@fontsource` 5.3.0） | 字节 | sha256 前 16 |
|---|---|---:|---|
| `Inter-400.ttf` | `inter/files/inter-latin-400-normal.woff` | 67 952 | `d3641a4ba1f6c109` |
| `Inter-500.ttf` | `inter/files/inter-latin-500-normal.woff` | 68 008 | `c0d48da478ee6c42` |
| `Inter-600.ttf` | `inter/files/inter-latin-600-normal.woff` | 68 060 | `e8f1310969c036c8` |
| `Inter-700.ttf` | `inter/files/inter-latin-700-normal.woff` | 67 988 | `f4d309afb4777beb` |
| `JetBrainsMono-400.ttf` | `jetbrains-mono/files/jetbrains-mono-latin-400-normal.woff` | 57 448 | `51de3d64b566c119` |
| `JetBrainsMono-500.ttf` | `jetbrains-mono/files/jetbrains-mono-latin-500-normal.woff` | 57 416 | `0de7133462bb7f23` |
| `Caveat-400.ttf` | `caveat/files/caveat-latin-400-normal.woff` | 116 908 | `27c09bce16aa2686` |
| `Caveat-600.ttf` | `caveat/files/caveat-latin-600-normal.woff` | 116 736 | `b90be193484e0974` |

`JetBrainsMono-400.ttf` 与 `_research/native/t1b/assets/fonts/JetBrainsMono-Latin-400.ttf` **同字节数**（57 448），即 T1b 当年做的是同一件事。

## 2. Chakra Petch（app 只带 woff2，Skia 预编译读不了）

| 文件 | 来源 | 字节 | sha256 前 16 | 用途 |
|---|---|---:|---|---|
| `ChakraPetch-SemiBoldItalic.ttf` | `https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/chakrapetch/ChakraPetch-SemiBoldItalic.ttf` | 81 000 | `4e11c1bec71511bb` | **面表实际使用** |
| `chakra-fontsource-600-italic-latin.woff` | `https://cdn.jsdelivr.net/npm/@fontsource/chakra-petch@5.3.0/files/chakra-petch-latin-600-italic.woff` | 14 372 | `1848b6ff755ba451` | A/B 证据 |
| `Chakra-fontsource-600-italic.ttf` | 上件经 `fonts-prepare` 同法重建 | 25 248 | `d924148109202e06` | A/B 证据 |

两个来源在同一条 oracle 行上量出**完全相同**的宽度（557.9183 px @ fs 39.0699、tracking 0.03），与 Chromium 的 557.78 差 **−0.138 px（0.025%）**；而用 OplusSans 替会差 −18.58 px。故：
- normal 样式请求**确实命中**这个 italic 面（Chromium 的匹配算法）；
- 替身与 app 的 woff2 同设计，残差登记为 GAP `e4-chakra-substitute`，不放宽任何阈值。

## 3. 系统 CJK 回退（机器状态，不随仓库走）

`C:/Windows/Fonts/msyh.ttc` face #0（Microsoft YaHei）。`person-1..5` 的“鹤/鹤羽轻风”10 行用整行回退测量 **Δ0.000 px**。
不是数据资产：换机器需重新核对（记入 E4.md §3.5）。
